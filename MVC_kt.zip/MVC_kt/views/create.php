<br>
<div>
    <h1>Form thêm mới</h1>
    <form action="" method="post">
        <label for="">ID</label><br>
        <input type="text" name="id"><br>
        <label for="">Name</label><br>
        <input type="text" name="name"><br>
        <label for="">Price</label><br>
        <input type="text" name="price"><br>
        <label for="">View</label><br>
        <input type="text" name="view"><br><br>
        <button type="submit" name="them">Them moi</button>
    </form>
</div>