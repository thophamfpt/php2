<?php

define('BASE_URL', 'http://localhost/WEB3014.03_php2/MVC_kt/index.php/');